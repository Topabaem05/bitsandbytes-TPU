"""Device-preserving Torch reference kernels for non-nested NF4.

The quantization and decoding rules derive from bitsandbytes default/ops.py.
Copyright (c) Facebook, Inc. and its affiliates. MIT license.
See THIRD_PARTY_NOTICES.md. No fused kernel or memory benefit is claimed.
Inputs must be finite. Scales must be finite and nonnegative.
These value preconditions are not tested inside the kernels.
"""
import torch
import torch.nn.functional as F

from .compatibility import check_dtype, check_kind, check_packed
from .blockwise import restored_scales
from . import exact

# Python values only. Import does not allocate a CPU or TPU tensor.
NF4_CODE = (-1.0, -0.6961928009986877, -0.5250730514526367,
            -0.39491748809814453, -0.28444138169288635,
            -0.18477343022823334, -0.09105003625154495, 0.0,
            0.07958029955625534, 0.16093020141124725, 0.24611230194568634,
            0.33791524171829224, 0.44070982933044434,
            0.5626170039176941, 0.7229568362236023, 1.0)


def quantize_4bit(A, blocksize, quant_type, quant_storage):
    check_kind(blocksize, quant_type)
    check_dtype(A.dtype)
    if quant_storage != torch.uint8:
        raise NotImplementedError("Only uint8 packed storage is supported")
    if A.numel() == 0:
        raise ValueError("Empty weights are not supported")
    code = torch.tensor(NF4_CODE, dtype=torch.float32, device=A.device)
    indices, scales = exact.quantize_words(exact.words(A), exact.words(code), 64)
    if indices.numel() % 2:
        indices = F.pad(indices, (0, 1), value=7)
    packed = ((indices[::2] << 4) | indices[1::2]).unsqueeze(1)
    return packed, exact.floats(scales)


def dequantize_4bit(A, absmax, blocksize, quant_type, shape, dtype):
    check_kind(blocksize, quant_type)
    count = check_packed(A, absmax, shape, dtype)
    packed = A.reshape(-1)
    indices = torch.stack((packed >> 4, packed & 15), dim=1).reshape(-1)[:count].to(torch.int32)
    code = torch.tensor(NF4_CODE, dtype=torch.float32, device=A.device)
    result = exact.decode_words(indices, exact.words(absmax), exact.words(code), 64)
    return exact.floats(result).reshape(shape).to(dtype)


def dequantize_4bit_out(A, absmax, blocksize, quant_type, shape, dtype, out):
    if tuple(out.shape) != tuple(shape) or out.dtype != dtype or out.device != A.device:
        raise ValueError("The output shape, dtype, and device must match")
    result = dequantize_4bit(A, absmax, blocksize, quant_type, shape, dtype)
    out.copy_(result)
    return None


def gemm_4bit(A, B, shapeB, absmax, blocksize, quant_type, bias=None,
              absmax_8bit=None, absmax_code=None, absmax_offset=None):
    check_kind(blocksize, quant_type)
    check_dtype(A.dtype)
    if len(shapeB) != 2 or A.ndim not in (2, 3) or A.shape[-1] != shapeB[1]:
        raise ValueError("GEMM needs rank2 or rank3 input and matching [N, K] weights")
    if A.device != B.device:
        raise ValueError("Input and packed weights must be on the same device")
    if bias is not None:
        if tuple(bias.shape) != (shapeB[0],) or bias.dtype != A.dtype or bias.device != A.device:
            raise ValueError("Bias must have shape [N] and the input dtype and device")
    if any(x is not None for x in (absmax_8bit, absmax_code, absmax_offset)):
        absmax = restored_scales(B, shapeB, absmax, absmax_8bit, absmax_code, absmax_offset)
    weights = dequantize_4bit(B, absmax, blocksize, quant_type, shapeB, A.dtype)
    return F.linear(A, weights, bias)
