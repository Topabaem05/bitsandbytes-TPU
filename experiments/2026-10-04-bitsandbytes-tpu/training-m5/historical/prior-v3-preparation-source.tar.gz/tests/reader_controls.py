"""Mutate disposable production-shaped records; mandatory complete-run failures."""
import copy,json,shutil
from pathlib import Path
import contract as C,inspect_actual as I

def exercise(packet,out,driver,review,cache=False):
 rows=[]
 def verify(d=None):return I.kernel_readbacks(packet,out,driver if d is None else d,review)
 good=verify();assert good['count']==(11 if cache else 10);rows.append({'name':'correct_complete_'+str(good['count']),'status':'PASS','evidence':good})
 if cache:
  changed=copy.deepcopy(driver);changed['kernel_proofs']=[r for r in changed['kernel_proofs']if r['label']!='wheel-cache']
  try:verify(changed)
  except ValueError as e:assert 'COMPLETE_KERNEL_READBACK_SET'in str(e);rows.append({'name':'required_cache_missing','status':'PASS','rejected':str(e)})
  else:raise AssertionError('required cache accepted missing')
  return rows
 backup=out.parent/'reader-pristine';shutil.copytree(out,backup);review_backup=out.parent/'review-pristine';shutil.copytree(review,review_backup)
 def mutate(name,fn,expected=None):
  d=copy.deepcopy(driver)
  try:
   fn(d);verify(d)
  except (ValueError,FileNotFoundError,KeyError)as e:
   if expected:assert expected in str(e),(name,str(e),expected)
   rows.append({'name':name,'status':'PASS','rejected':str(e)})
  else:raise AssertionError('reader accepted '+name)
  finally:
   shutil.rmtree(out);shutil.copytree(backup,out);shutil.rmtree(review);shutil.copytree(review_backup,review)
 def proof(d,change,label='remote-install'):
  p=out/'kernel-readbacks'/(label+'-proof.json');v=C.read(p);change(v);C.write(p,v)
  next(r for r in d['kernel_proofs']if r['label']==label)['proof_sha256']=C.sha(p)
 def cli(d,label,change):
  row=next(r for r in d['commands']if r['label']==label);directory=next((out/'cli').glob('*-'+label));r=C.read(directory/'result.json');o=C.read(directory/'ownership.json');cl=C.read(directory/'cleanup.json');change(r,o,cl,row);C.write(directory/'result.json',r);C.write(directory/'ownership.json',o);C.write(directory/'cleanup.json',cl)
 def argv(d,label,change):
  def edit(r,o,cl,row):change(r['argv']);o['argv']=r['argv']
  cli(d,label,edit)
 def remove(d,labels,physical=True):
  d['kernel_proofs']=[r for r in d['kernel_proofs']if r['label']not in labels];d['commands']=[r for r in d['commands']if r['label']not in labels];d['provider_calls']=len(d['commands'])
  if physical:
   for label in labels:
    for p in(out/(label+'.py'),):
     if p.exists():p.unlink()
    for p in(out/'kernel-readbacks').glob(label+'*'):p.unlink()
    for p in(out/'cli').glob('*-'+label):shutil.rmtree(p)
 def all_removed(d):
  d.update(commands=[],kernel_proofs=[],provider_calls=0)
  for p in out.glob('*.py'):p.unlink()
  shutil.rmtree(out/'cli');(out/'cli').mkdir();shutil.rmtree(out/'kernel-readbacks');(out/'kernel-readbacks').mkdir()
 mutate('all_rows_and_all_physical_removed',all_removed,'COMPLETE_KERNEL_READBACK_SET')
 mutate('all_mutable_rows_removed_keep_physical',lambda d:d.update(commands=[],kernel_proofs=[],provider_calls=0),'COMPLETE_KERNEL_READBACK_SET')
 mutate('install_pair_and_physical_removed',lambda d:remove(d,{'remote-install','remote-install-completion','remote-install-artifact'}),'COMPLETE_KERNEL_READBACK_SET')
 mutate('missing_export_and_dispose',lambda d:remove(d,{'export-device','dispose-device'}),'COMPLETE_KERNEL_READBACK_SET')
 mutate('empty_physical_cli_inventory',lambda d:shutil.rmtree(out/'cli'))
 mutate('missing_submitted_install_script',lambda d:(out/'remote-install.py').unlink(),'EXACT_PHYSICAL_SUBMITTED_SCRIPTS')
 mutate('extra_submitted_exec_script',lambda d:(out/'unexpected.py').write_text('print(1)'),'EXACT_PHYSICAL_SUBMITTED_SCRIPTS')
 mutate('duplicate_phase',lambda d:d['kernel_proofs'].__setitem__(-1,copy.deepcopy(d['kernel_proofs'][0])),'COMPLETE_KERNEL_READBACK_SET')
 nonce=C.read(out/'kernel-readbacks/browser-marker-proof.json')['request']['nonce']
 mutate('duplicate_nonce',lambda d:proof(d,lambda v:v['request'].update(nonce=nonce)),'UNIQUE_KERNEL_NONCE')
 for label in ['artifact_path','artifact_expected']:
  for name,value in([('none',None),('wrong_path','/content/other.json')]if label=='artifact_path'else[('dropped',{})]):
   mutate('weakened_'+label+'_'+name,lambda d,label=label,value=value:proof(d,lambda v:v['request'].__setitem__(label,value)),'CANONICAL_KERNEL_REQUEST')
 mutate('wrong_request_source_sha',lambda d:proof(d,lambda v:v['request'].update(admitted_source_sha256='a'*64)),'CANONICAL_KERNEL_REQUEST')
 mutate('completion_path_inside_base',lambda d:proof(d,lambda v:v['request'].update(completion_path=driver['remote_base']+'/completion.json')),'CANONICAL_KERNEL_REQUEST')
 def body(d):
  p=out/'remote-install.py';p.write_text(p.read_text()+'\nprint("changed body")\n');proof(d,lambda v:v.update(submitted_source_sha256=C.sha(p)));next(r for r in d['kernel_proofs']if r['label']=='remote-install')['submitted_source_sha256']=C.sha(p)
 mutate('resealed_wrong_submitted_source',body,'CANONICAL_SUBMITTED_KERNEL_SOURCE')
 mutate('wrong_exec_session',lambda d:argv(d,'remote-install',lambda a:a.__setitem__(5,'another-session')),'EXACT_SUBMITTED_CLI_EXEC')
 mutate('wrong_exec_file',lambda d:argv(d,'remote-install',lambda a:a.__setitem__(-1,str(out/'remote-cpu.py'))),'EXACT_SUBMITTED_CLI_EXEC')
 mutate('bare_cli_prefix',lambda d:argv(d,'remote-install',lambda a:a.__delitem__(slice(0,3))),'ADMITTED_CLI_PREFIX_AND_ARGV')
 mutate('module_cli_prefix',lambda d:argv(d,'remote-install',lambda a:a.__setitem__(2,'-m')),'ADMITTED_CLI_PREFIX_AND_ARGV')
 mutate('different_cli_python',lambda d:argv(d,'remote-install',lambda a:a.__setitem__(0,'/other/python')),'ADMITTED_CLI_PREFIX_AND_ARGV')
 mutate('completion_download_wrong_source',lambda d:argv(d,'remote-install-completion',lambda a:a.__setitem__(-2,'content/another.json')),'CANONICAL_CLI_OPERATION')
 mutate('artifact_download_wrong_destination',lambda d:argv(d,'remote-install-artifact',lambda a:a.__setitem__(-1,str(out/'other.json'))),'CANONICAL_CLI_OPERATION')
 mutate('completion_download_absent',lambda d:remove(d,{'remote-install-completion'}),'COMPLETE_CANONICAL_CLI_COMMAND_SEQUENCE')
 def extra(d):
  d['commands'].insert(4,copy.deepcopy(d['commands'][4]));d['provider_calls']+=1
 mutate('extra_exec_command',extra,'COMPLETE_CANONICAL_CLI_COMMAND_SEQUENCE')
 def failed_child(d):
  def edit(r,o,c,row):o['exit_status']=1;o['cleanup']['exit_status']=1;c['groups'][0]['exit_status']=1;r['cleanup']=c;row['cleanup']=c
  cli(d,'remote-install',edit)
 mutate('cli_zero_failed_owned_child',failed_child,'OWNED_CLI_PROCESS_OUTCOME')
 def dirty(d):
  def edit(r,o,c,row):c['errors']=['synthetic dirty closure'];r['cleanup']=c;row['cleanup']=c
  cli(d,'remote-install',edit)
 mutate('resealed_dirty_cli_closure',dirty,'OWNED_CLEANUP_ERRORS')
 def missing_result(d):next((out/'cli').glob('*-remote-install/result.json')).unlink()
 mutate('physical_result_absent',missing_result,'COMPLETE_PHYSICAL_CLI_RECORDS')
 mutate('physical_raw_error_after_marker',lambda d:next((out/'cli').glob('*-remote-install/stdout-stderr.raw')).write_text('ValueError: kernel failed\n'),'KERNEL_COMPLETION_LINE')
 mutate('extra_physical_exec_directory',lambda d:shutil.copytree(next((out/'cli').glob('*-remote-install')),out/'cli/999-extra-exec'),'EXACT_PHYSICAL_CLI_DIRECTORIES')
 def ownership_argv(d):
  p=next((out/'cli').glob('*-remote-install/ownership.json'));o=C.read(p);o['argv']=['wrong'];C.write(p,o)
 mutate('result_ownership_argv_disagree',ownership_argv,'ADMITTED_CLI_PREFIX_AND_ARGV')
 def export_summary(d):
  p=out/'recovery-cpu/summary.json';v=C.read(p);v['unexpected']='resealed mutable summary';C.write(p,v)
 mutate('independent_export_summary_bytes_changed',export_summary,'EXPORT_SUMMARY_INDEPENDENT_BYTES')
 def lifecycle(d):
  p=next((out/'cli').glob('*-remote-install/lifecycle.jsonl'));p.write_text(json.dumps({'kind':'child_started','pid':1,'pgid':1})+'\n')
 mutate('wrong_physical_lifecycle',lifecycle,'CLI_LIFECYCLE_PROCESS_BINDING')
 mutate('partial_execution_not_complete',lambda d:d.update(status='BLOCKED'), 'PARTIAL_EXECUTION_NOT_COMPLETE')
 mutate('wrong_host_owner_argv',lambda d:C.write(review/'host-owner/ownership.json',{**C.read(review/'host-owner/ownership.json'),'argv':['wrong']}),'OWNED_CLI_PROCESS_OUTCOME')
 mutate('wrong_host_config_source',lambda d:C.write(review/'dispatch/host-config.json',{**C.read(review/'dispatch/host-config.json'),'argv':['wrong']}),'ADMITTED_HOST_DRIVER_PREFIX')
 def cache_required(d):
  p=review/'dispatch/host-config.json';v=C.read(p);v['argv']+=['--runtime-wheels','/synthetic/cache'];C.write(p,v)
  p=review/'host-owner/host-finalization.json';h=C.read(p);h.update(argv=v['argv'],config_sha256=C.sha(review/'dispatch/host-config.json'));h['cleanup']['groups'][0]['exit_status']=0;C.write(p,h)
  p=review/'host-owner/ownership.json';o=C.read(p);o['argv']=v['argv'];C.write(p,o)
 mutate('required_cache_config_with_no_cache',cache_required,'COMPLETE_KERNEL_READBACK_SET')

 shutil.rmtree(backup);shutil.rmtree(review_backup);return rows
