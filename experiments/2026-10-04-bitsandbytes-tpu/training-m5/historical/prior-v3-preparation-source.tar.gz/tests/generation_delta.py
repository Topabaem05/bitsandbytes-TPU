"""Closed portable v2-to-reader-v3 source delta; science unchanged."""
import ast,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((ROOT/'historical/prior-v2-science-manifest.json').read_text());current=json.loads((ROOT/'source/science-manifest.json').read_text())
assert sha(ROOT/'historical/prior-v2-science-manifest.json')=='eaa46938407334a53bbdda4d7ea6bd48ae8837e93b7e33788bd2850e78ed2e88'
added=set(current['files'])-set(prior['files']);assert added=={'control/kernel_entries.py','control/kernel_reader.py'}
assert not(set(prior['files'])-set(current['files']))
changed={n for n,r in prior['files'].items()if current['files'][n]!=r};assert changed=={'control/driver.py','control/inspect_actual.py','source/admission.py','integration/source-admission.json'},changed
old=ast.parse((ROOT/'historical/prior-v2-admission.py').read_text());new=ast.parse((ROOT/'source/admission.py').read_text())
for tree in [old,new]:tree.body=[n for n in tree.body if not(isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='GENERATION'for t in n.targets))]
assert ast.dump(old,include_attributes=False)==ast.dump(new,include_attributes=False)
a=json.loads((ROOT/'historical/prior-v2-integration-admission.json').read_text());b=json.loads((ROOT/'integration/source-admission.json').read_text());a.pop('generation');b.pop('generation');assert a==b
assert sha(ROOT/'control/kernel_protocol.py')=='e9c7a5b7b943cea08dfb8986205e47e008ceac37553a2f8576687527a58f9d5f'
assert sha(ROOT/'integration/plugin/src/bitsandbytes_tpu/exact.py')=='49511fbc22e93ca9ca765da9930c8975e44ae389b605fe85747ddf7c73486830'
assert sha(ROOT/'integration/plugin/src/bitsandbytes_tpu/_source_order.py')=='54728c36190c64334ffceb2b12d1cabcfff87ca35a8387a24766ae4dba191b75'
result={'status':'PASS','prior_science_manifest_sha256':sha(ROOT/'historical/prior-v2-science-manifest.json'),'new_science_manifest_sha256':sha(ROOT/'source/science-manifest.json'),'added':sorted(added),'changed':sorted(changed),'admission_only_generation_constant_changed':True,'integration_admission_only_generation_changed':True,'shared_kernel_helper_exact_unchanged':True,'training_math_reader_reference_and_plugin_bytes_unchanged':True,'frozen20_steps_save10_resume10_and_1024_guards_unchanged':True,'local20_repeat':'NOT_RUN_NO_SCIENTIFIC_BYTE_CHANGE_PRIOR_V2_EVIDENCE_RETAINED','provider_calls':0,'m5_status':'NOT_QUALIFIED'}
Path(sys.argv[1]).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({'status':'PASS','closed_source_delta':True}))
