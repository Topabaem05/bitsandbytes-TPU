"""Valid gzip/tar with wrong member bytes must fail after whole-SHA validation."""
import hashlib,io,json,sys,tarfile,tempfile
from pathlib import Path
from bundle_readback import verify,sha
with tempfile.TemporaryDirectory(prefix='bnb-m5-v2-bundle-fixture-',dir='/tmp')as td:
 p=Path(td);(p/'a').write_bytes(b'correct');manifest={'files':{'a':{'sha256':sha(p/'a'),'bytes':7}}};(p/'source-closure.json').write_text(json.dumps(manifest))
 def bundle(path,wrong=False):
  with tarfile.open(path,'w:gz')as t:
   for name in ['a','source-closure.json']:
    b=b'incorrect'if wrong and name=='a'else(p/name).read_bytes();i=tarfile.TarInfo(name);i.size=len(b);t.addfile(i,io.BytesIO(b))
 bundle(p/'good.tar.gz');verify(p,p/'good.tar.gz',sha(p/'good.tar.gz'))
 bundle(p/'wrong.tar.gz',True)
 try:verify(p,p/'wrong.tar.gz',sha(p/'wrong.tar.gz'))
 except ValueError as e:assert str(e)=='SOURCE_MEMBER_BYTES:a'
 else:raise AssertionError('wrong member accepted')
result={'status':'PASS','controls':2,'correct_full_readback':'PASS','valid_gzip_tar_wrong_member_correct_whole_sha':'REJECTED','fixtures_deleted':not Path(td).exists(),'provider_calls':0}
Path(sys.argv[1]).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result))
