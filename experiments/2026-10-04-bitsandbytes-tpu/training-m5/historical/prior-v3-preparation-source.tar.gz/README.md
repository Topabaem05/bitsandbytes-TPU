M5 reader v3 closes missing-phase and physical CLI inventory false positives in the frozen M5 v2 preparation. This candidate remains unqualified and requires genuine externally supplied root acceptance of M4 exact79 plus state8. The previous M5 candidate remains frozen and unadopted.

# M5 portable preparation

This source package prepares the frozen M5 test. It does not qualify M5. No provider call, qualified Linux training run, or TPU run was made by the preparer.

The retained prior-v2 local unqualified test completed 20 updates, saved after update 10, and resumed updates 11–20 in a fresh process. The independent reader passed 200 continuation comparisons and 400 dense-reference comparisons. The full final model matched exactly. The test also compared the full frozen base state and the complete SGD checkpoint. It used Darwin arm64, Python 3.12.14, and Torch 2.14.1. These retained results do not qualify the new generation or satisfy the Linux or TPU gates. Local training was not repeated: the closed v2 delta verifies unchanged training, checkpoint, numerical reader, reference and plugin bytes. All 26,450,507 bytes of test records and the 99,765-byte checkpoint were deleted after compact seals were saved.

The original protocol and input hashes remain `bd221d5dcd8a06a3080ff30345f80b8b99d8ca609fadcb813ea8da09964d007f` and `f16b79f90556d3d2eb01c4340af03be5c561e5b70591d6754ffdd990fb14002e`. The model remains two width-256 `Linear4bit` layers, rank-4 adapters, batch 8, FP32 MSE, and SGD at 0.01. There is no activation or dropout. The base weights, biases, and all nested state stay frozen.

The distinct M5 reader v3 source generation is `nested-exact-m5-1024-scope-v3`. It admits 1–513 or exactly 1024 first scales. It rejects 514–1023 and 1025. Only the two previously reviewed guard changes in `exact.py` and `_source_order.py` extend the M4 arithmetic. The original M4 files still reject 1024. The 17 scope controls pass against fresh default-body byte references and a separate Fraction-based reduction and encoding reference. They do not use a historical checkpoint. M4 acceptance alone cannot qualify the 1024 extension.

The CPU primary uses the pinned default Python byte bodies and independent dense FP32 autograd. It constructs and restores state with the original public classes and methods. It does not register CPU quantization kernels or claim public CPU forward coverage. The TPU path uses the original public `Linear4bit` forward, original transfer and checkpoint methods, ordinary plugin discovery, and the separately admitted 1024 candidate. It captures typed composite graphs, original positional arguments, source frames, functionalization state, parameter values, execution metrics, and each training step's FP32 highest-precision HLO. The reader compares all 400 returned device gates against a fresh qualified Linux CPU primary, in addition to the 200 continuation and 400 dense-reference gates.

## Blocking dependency

A dispatchable packet cannot be built until root supplies a genuine accepted M4 record covering all 79 exact cases and all eight saved-state cases, with independent readback and resource closure. `source/admission.py:m4_dependency` is a proposed strict consumer schema. It does not write acceptance. Root must reconcile it with the final reviewed M4 acceptance schema before adoption. The parser requires the unchanged M4 base admission, science map, integration map, and runtime hashes; exact 79/8 counts; fresh state restore; exact checkpoint tensors; all closure flags; nine nonzero provenance hashes; and an acceptance time no later than the current time. A case verifier PASS or an offline synthetic fixture cannot substitute for root acceptance.

The base admission is `75790f1d4613e20daa06d99111288463ef24b05aaa29922a7580512078f9912f`; the base science map is `9e71efc73b0f2b3a210f8131c10972569a5e2d04cf298fcf5a8da59772cf4f5a`. The old M4 candidate archive SHA is historical copy provenance only. No executable path reads an old M4, public, or compiler scratch directory.

The existing official CLI identity and all 35 Linux runtime wheels were read and hash-checked. The wheel cache contains 572,327,598 locked bytes. Qualified execution requires Linux x86_64, Python 3.12.14, Torch 2.9.0+cpu at the pinned Git commit, AVX2, and one CPU thread. Device execution additionally requires the locked Torch-XLA, libtpu, JAX, and JAXlib versions. Only root's actual owned cloud flow may install them. The preparer installed nothing.

## Offline replay

These commands make no provider calls. Each test deletes its temporary fixtures, including on failure.

```sh
M5=/tmp/bnb-tpu-m5-reader-v3-20261011-0k41zyv4
PY=/Users/topamini/code/Post2TPU/.venv/bin/python
OUT=$(mktemp -d /tmp/bnb-tpu-root-m5-reader-v3-review-20261011-XXXXXX)
"$PY" -B "$M5/tests/frozen_science.py" "$OUT/frozen-science-replay.json"
"$PY" -B "$M5/tests/scope_controls.py" "$OUT/scope-replay.json"
"$PY" -B "$M5/tests/cloud_controls.py" "$OUT/cloud-replay.json"
```

The existing controls cover 17 arithmetic scope cases, 58 source/cloud cases, and 18 local training/checkpoint/readback cases. Reader v3 reruns the 17 scope and 58 source/cloud controls, 20 frozen reference functions, 29 exact shared kernel controls, 13 synthetic driver scenarios and 39 complete-reader controls. The 18 prior local checkpoint/training controls and prior actual local20/save10/freshresume results are retained as historical v2 evidence. They were not rerun or relabeled as current-generation training. Cloud controls use isolated synthetic schema and transport fixtures. They exercise the real packet, request, observe, and dispatch preparation branches. They do not establish actual M4 acceptance, Linux qualification, or device execution. Wrong cases include missing checkpoint tensors, changed frozen bytes, wrong optimizer mapping and learning rate, changed gradients with resealed envelopes, incomplete steps, wrong process IDs, error-bearing complete records, stale UI observations, request clock reset, missing state8, wrong source hashes, unsafe archives, and false closure records.

## Root source review and packet build

Run only after review. Root must supply `M4_ACCEPTANCE`, its independently established `M4_SHA`, `REVIEWED_BASE_COMMIT`, and a fresh `ROOT_REVIEW` directory path. None is inferred from an old acceptance or archive.

```sh
CLI=/Users/topamini/code/Post2TPU/.runtime/cloud-cli/bin/python
IDENTITY=/Users/topamini/code/bitsandbytes-TPU/.work/task2-cloud/cli-identity.json
WHEELS=/Users/topamini/code/bitsandbytes-TPU/.work/cache/bitsandbytes-tpu-wheelhouse
: "${M4_ACCEPTANCE:?Supply the genuine accepted M4 79+8 record path}"
: "${M4_SHA:?Supply its independently established SHA-256}"
: "${REVIEWED_BASE_COMMIT:?Supply the reviewed canonical base commit}"
: "${ROOT_REVIEW:?Supply a fresh absolute root review directory path}"
"$PY" -B "$M5/control/root_records.py" source-review --source "$M5" \
  --reviewed-base-commit "$REVIEWED_BASE_COMMIT" \
  --reviewer-decision ACCEPT_SOURCE_AFTER_ROOT_REVIEW \
  --output "$ROOT_REVIEW/source-review.json"
REVIEW_SHA=$("$PY" -c 'import hashlib,sys;print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())' "$ROOT_REVIEW/source-review.json")
"$PY" -B "$M5/control/build_packet.py" --source "$M5" \
  --source-review "$ROOT_REVIEW/source-review.json" --source-review-sha256 "$REVIEW_SHA" \
  --m4-acceptance "$M4_ACCEPTANCE" --m4-acceptance-sha256 "$M4_SHA" \
  --output "$ROOT_REVIEW/packet"
PACKET_SHA=$("$PY" -c 'import hashlib,sys;print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())' "$ROOT_REVIEW/packet.zip")
"$PY" -B "$M5/control/root_records.py" check --packet "$ROOT_REVIEW/packet" \
  --packet-zip "$ROOT_REVIEW/packet.zip" --packet-sha256 "$PACKET_SHA" \
  --cli-python "$CLI" --cli-identity "$IDENTITY" --runtime-wheels "$WHEELS"
```

## One actual allocation

Root executes these provider modes. The original allocation clock is recorded immediately before Connect. It cannot be reset by a second request. The fixed total budget is 3600 seconds: install 1200, science 1800, retrieval 600, cleanup 60. Science stops at the original deadline minus 660 seconds. CPU preparation is bounded to 300 seconds; device training to 1500. Each phase also has a finite deadline. The owner never extends the original clock. Cache uploads and other overhead consume that same clock. A slow phase fails closed.

The source packet and complete recovered envelope are bounded to 100 MiB and 2000 files, with 96 MiB inside. CPU recovery also retains the 64 MiB bound. Graphs use the adopted lossless object store. Evidence limits remain failures, not exemptions.

```sh
root_record() {
  "$PY" -B "$M5/control/root_records.py" "$1" \
    --packet "$ROOT_REVIEW/packet" --packet-zip "$ROOT_REVIEW/packet.zip" \
    --packet-sha256 "$PACKET_SHA" --review "$ROOT_REVIEW/connect" \
    --output "$ROOT_REVIEW/actual" --cli-python "$CLI" --cli-identity "$IDENTITY" \
    --runtime-wheels "$WHEELS" "${@:2}"
}
root_record preconnect
root_record request
```

Preconnect requires an empty server and zero usage and closes the owned CLI groups. Root then opens a new empty notebook with one V5E1 TPU assignment, performs Connect once, and runs `connect/browser-marker-cell.py`. Root must observe the exact hardware and marker output. Record that output within 180 seconds:

```sh
: "${MARKER_OUTPUT:?Supply the exact marker stdout observed by root in the notebook UI}"
root_record observe --marker-output "$MARKER_OUTPUT"
root_record dispatch --reviewer-decision AUTHORIZE_ONE_ALLOCATION_AFTER_ROOT_REVIEW
"$PY" -B "$M5/control/host_run.py" --config "$ROOT_REVIEW/connect/dispatch/host-config.json"
```

Dispatch requires a fresh UI observation bound to the original request, marker, packet, and V5E1 hardware. It lists one unregistered endpoint and writes a bound adoption record. The driver adopts that endpoint through the existing official owner, reads the marker back remotely, and makes zero allocation attempts. It installs only the admitted runtime and sources. It then runs fresh Linux CPU20/save10/resume10, recovers the complete CPU archive, and verifies source, wheels, process ownership, closure, and all training comparisons before uploading the CPU gate. Only then can it start the device cases. Every terminal scientific phase is recovered before the next stage. On the first error, it stops further science and enters closure.

The final recovered ZIP remains for independent readback. Transfer copies and a superseded CPU archive are deleted only after verified replacement. If an error prevents identity verification or recovery, the driver retains the error and does not claim closure or acceptance. Root must resolve any remaining owned runtime through the reviewed ownership procedure.

## Independent final readback

After the driver has stopped the exact owned assignment, root closes its browser tab and observes that the tab is absent. Then run a fresh server and usage readback. `OWNED_TAB_ID` must name the tab root actually closed.

```sh
root_record fresh-closure
: "${OWNED_TAB_ID:?Supply the browser tab ID root closed and observed absent}"
root_record tab-closure --tab-id "$OWNED_TAB_ID" --tab-absent
"$PY" -B "$M5/control/inspect_actual.py" --packet "$ROOT_REVIEW/packet" \
  --packet-zip "$ROOT_REVIEW/packet.zip" --packet-sha256 "$PACKET_SHA" \
  --actual "$ROOT_REVIEW/actual" --review "$ROOT_REVIEW/connect" \
  --output "$ROOT_REVIEW/independent-readback.json"
```

The reader verifies the complete ZIP against the recovered files, repeats the independent scientific checks, and checks the original clock, owned groups, fresh empty server, zero usage, and root-observed tab closure. It still reports `m5_status=NOT_QUALIFIED`; root owns the final milestone decision. TPU execution cost, final graph envelope fit, and all device numerics remain unmeasured. No M6 qualification or performance claim follows from this preparation.

Every submitted kernel entry sets `sys.dont_write_bytecode=True` and `PYTHONDONTWRITEBYTECODE=1` before importing sealed code. Completion requires one fresh phase/source/nonce-bound success marker as the last nonempty output line, an independently downloaded completion JSON with matching SHA, and an independently downloaded phase/export artifact with matching SHA and fields when the entry produces one. Completion records live in a sibling directory so the initial marker cannot occupy the fresh remote base before readiness. Missing, duplicated, stale, altered, or post-error markers fail closed despite CLI exit zero. Initialization failures attempt diagnostic recovery; science failures recover terminal or partial records before exact-runtime closure under the original allocation clock. The independent final reader first validates admitted dispatch, host config and owned host outcome. It derives ten mandatory phases and the optional eleventh wheel-cache phase only from the admitted host argv. Required phases, independently stored submitted scripts, unique CLI execs, and proof rows must agree exactly. Every submitted script is regenerated from the canonical phase body, artifact contract and observed unique nonce. All serial CLI directories must match the canonical sequence with the admitted official CLI prefix; result argv, ownership argv, process exit, cleanup, lifecycle and raw output are cross-checked. Completion and artifact download source/destination paths are reconstructed, and separately downloaded export summaries must have identical bytes. Missing or partial execution reports PARTIAL_OR_INVALID and cannot establish complete execution.

Additional bounded replay commands, with OUT set to a fresh review directory outside this candidate:

```bash
PYTHONDONTWRITEBYTECODE=1 "$PY" -B "$M5/tests/generation_delta.py" "$OUT/generation-delta.json"
PYTHONDONTWRITEBYTECODE=1 "$PY" -B "$M5/tests/kernel_controls.py" "$OUT/kernel-controls.json"
PYTHONDONTWRITEBYTECODE=1 "$PY" -B "$M5/tests/driver_controls.py" "$OUT/driver-controls.json"
```

The interactive tests deliberately start with bytecode writing enabled, reproduce the old failure, then verify fresh unpack, strict readmission, inherited child bytecode suppression, and cached-module controls. Driver tests use explicit synthetic transport/science/audit fixtures; they are not qualified Linux or TPU results. The authorized local smoke remains real but unqualified.

Complete source bundle independent readback (the archive SHA must come from root's established review):

```sh
: "${SOURCE_TAR_SHA:?Supply the independently established source tar SHA-256}"
"$PY" -B "$M5/tests/bundle_readback.py" --source "$M5" \
  --archive "$M5/m5-reader-v3-preparation-source.tar.gz" --expected-sha256 "$SOURCE_TAR_SHA" \
  --output "$OUT/source-bundle-readback.json"
"$PY" -B "$M5/tests/bundle_controls.py" "$OUT/bundle-controls.json"
```

The portable delta check reads closed historical manifests, not old scratch directories. The shared `kernel_protocol.py` remains byte-identical at `e9c7a5b7b943cea08dfb8986205e47e008ceac37553a2f8576687527a58f9d5f`. The reader controls deliberately use production-shaped full official CLI argv and realistic structured ownership/result/cleanup/lifecycle records. They do not invoke the CLI or a provider. Tests need the existing read-only installed CLI identity and interpreter shown above; they install nothing. Synthetic cache uploads do not copy the 572 MB Linux wheel cache. All synthetic M4 acceptance fixtures are explicitly test-only and are deleted; no actual acceptance is created.

At seal time, root had recovered a qualified Linux M4 CPU79 PASS and a separate actual TPU functional-tensor error before numerics. This reader-only generation retains the inherited plugin bytes. Any M4 plugin repair requires a separate reviewed M5 source rebase; it cannot be applied silently to this frozen bundle. Genuine accepted M4 79+8 is still unavailable.
